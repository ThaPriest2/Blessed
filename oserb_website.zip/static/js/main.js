
AOS.init({
  duration: 800,
  once: true,
  easing: 'ease-in-out',
});

document.getElementById("mobileMenuBtn").onclick = function () {
  const menu = document.getElementById("mobileMenu");
  menu.classList.toggle("hidden");
};

document.getElementById("darkModeToggle").onclick = function () {
  document.documentElement.classList.toggle("dark");
};
